# CPChallenge - Leaping likes

A Pen created on CodePen.io. Original URL: [https://codepen.io/tommyho/pen/NWJEpaj](https://codepen.io/tommyho/pen/NWJEpaj).

A mouse clicker that blasting red hearts